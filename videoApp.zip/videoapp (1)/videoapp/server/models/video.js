const mongoose=require('mongoose');

const Schema=mongoose.Schema;
const videosSchem=new Schema({
title:String,
url:String,
description:String

});

module.exports=mongoose.model('video',videosSchem,'videos');